import os
from flask_sqlalchemy import SQLAlchemy

# 1) Add this Config class so app.py can import it:
class Config:
    # SQLite by default, override with DATABASE_URI env var if you like:
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URI', 'sqlite:///grading.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.environ.get('UPLOAD_FOLDER', 'uploads')

# 2) Your existing DB + models:
db = SQLAlchemy()

class Submission(db.Model):
    id              = db.Column(db.Integer, primary_key=True)
    student_name    = db.Column(db.String(128))
    birthday_prefix = db.Column(db.String(10))
    master_zip      = db.Column(db.String(256))
    student_zip     = db.Column(db.String(256))
    final_score     = db.Column(db.Float)
    created_at      = db.Column(db.DateTime, server_default=db.func.now())

class RouterResult(db.Model):
    id             = db.Column(db.Integer, primary_key=True)
    submission_id  = db.Column(db.Integer, db.ForeignKey('submission.id'))
    router_name    = db.Column(db.String(128))
    score          = db.Column(db.Integer)
    feedback       = db.Column(db.Text)
    diff           = db.Column(db.Text)
