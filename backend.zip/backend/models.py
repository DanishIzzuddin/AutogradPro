from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Submission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_name = db.Column(db.String(128))
    birthday_prefix = db.Column(db.String(10))
    master_zip = db.Column(db.String(256))
    student_zip = db.Column(db.String(256))
    final_score = db.Column(db.Float)
    created_at = db.Column(db.DateTime, server_default=db.func.now())

class RouterResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    submission_id = db.Column(db.Integer, db.ForeignKey('submission.id'))
    router_name = db.Column(db.String(128))
    score = db.Column(db.Integer)
    feedback = db.Column(db.Text)
    diff = db.Column(db.Text)
