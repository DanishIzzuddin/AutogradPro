// backend/routes.js
const express = require('express');
const jwt     = require('jsonwebtoken');
const db      = require('./db');
const router  = express.Router();

function authenticateJWT(req, res, next) {
  const header = req.headers.authorization;
  if (!header) return res.status(401).end();
  const token = header.split(' ')[1];
  jwt.verify(token, process.env.JWT_SECRET, (err, payload) => {
    if (err) return res.status(403).end();
    req.user = payload;
    next();
  });
}

router.get('/lecturer/subjects', authenticateJWT, async (req, res) => {
  try {
    if (req.user.role !== 'lecturer') return res.status(403).end();
    const [subs] = await db.query(
      `SELECT s.id, s.code, s.name
       FROM subjects s
       JOIN teacher_subjects ts ON ts.subject_id = s.id
       WHERE ts.teacher_id = ?`,
      [req.user.sub]
    );
    res.json(subs);
  } catch (err) {
    console.error('Error in GET /lecturer/subjects:', err);
    res.status(500).json({ message: err.message });
  }
});

router.get('/lecturer/subjects/:sid/assignments', authenticateJWT, async (req, res) => {
  try {
    if (req.user.role !== 'lecturer') return res.status(403).end();
    const subjectId = +req.params.sid;
    const [asgn] = await db.query(
      `SELECT id, title, description, due_date
       FROM assignments
       WHERE subject_id = ?`,
      [subjectId]
    );
    res.json(asgn);
  } catch (err) {
    console.error('Error in GET /lecturer/subjects/:sid/assignments:', err);
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
