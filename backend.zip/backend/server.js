// server.js
require('dotenv').config();

const express    = require('express');
const cors       = require('cors');
const bodyParser = require('body-parser');
const multer     = require('multer');
const path       = require('path');
const fs         = require('fs');
const { spawn }  = require('child_process');

const db            = require('./db');
const authRouter    = require('./auth');
const lecturerRouter= require('./routes');  // <— your lecturer endpoints

const app  = express();
const PORT = process.env.PORT || 5000;

// ─── MIDDLEWARE ───────────────────────────────────────────────────────
app.use(cors({ origin: 'http://localhost:3000', credentials: true }));
app.use(bodyParser.json());

// ─── ROUTES ────────────────────────────────────────────────────────────
// Auth routes
app.use('/api/auth', authRouter);

// Lecturer routes (subjects & assignments)
app.use('/api', lecturerRouter);

// Health-check
app.get('/', (req, res) => {
  res.send('Backend is working');
});

// Ensure uploads directory exists
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads');
}

// Multer setup for file uploads
const storage = multer.diskStorage({
  destination(req, file, cb) {
    cb(null, 'uploads/');
  },
  filename(req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

// ─── EXISTING ENDPOINTS (UNCHANGED) ──────────────────────────────────

// List all users
app.get('/users', (req, res) => {
  db.query('SELECT id, username, name, role FROM users', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

// View submissions for an assignment
app.get('/submissions/:assignmentId', (req, res) => {
  const assignmentId = req.params.assignmentId;
  const sql = `
    SELECT 
      u.id AS student_id,
      u.name AS student_name,
      s.submitted_at,
      s.score,
      s.plagiarism,
      s.feedback
    FROM users u
    LEFT JOIN submissions s 
      ON u.id = s.student_id 
      AND s.assignment_id = ?
    WHERE u.role = 'student'
    ORDER BY u.name
  `;
  db.query(sql, [assignmentId], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

// Get single submission detail
app.get('/submission', (req, res) => {
  const { student, assignment } = req.query;
  const sql = `
    SELECT 
      u.name AS student_name,
      a.title AS assignment_title,
      s.submitted_at,
      s.score,
      s.plagiarism,
      s.feedback
    FROM submissions s
    JOIN users u    ON s.student_id    = u.id
    JOIN assignments a ON s.assignment_id = a.id
    WHERE s.student_id = ? AND s.assignment_id = ?
  `;
  db.query(sql, [student, assignment], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    if (results.length === 0) {
      return res.status(404).json({ message: "No submission found." });
    }
    res.json(results[0]);
  });
});

// Save feedback
app.post('/submission/feedback', (req, res) => {
  const { studentId, assignmentId, feedback } = req.body;
  const sql = `
    UPDATE submissions
    SET feedback = ?
    WHERE student_id = ? AND assignment_id = ?
  `;
  db.query(sql, [feedback, studentId, assignmentId], err => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Feedback saved successfully." });
  });
});

// Assignment performance stats
app.get('/assignment-performance/:assignmentId', (req, res) => {
  const assignmentId = req.params.assignmentId;

  const statsSql = `
    SELECT 
      COUNT(*) AS total_submissions,
      AVG(score) AS average_score
    FROM submissions
    WHERE assignment_id = ?
      AND score IS NOT NULL
  `;
  const topSql = `
    SELECT u.name AS student_name, s.score, s.plagiarism, s.feedback
    FROM submissions s
    JOIN users u ON s.student_id = u.id
    WHERE s.assignment_id = ? AND s.score IS NOT NULL
    ORDER BY s.score DESC
    LIMIT 3
  `;
  const bottomSql = `
    SELECT u.name AS student_name, s.score, s.plagiarism, s.feedback
    FROM submissions s
    JOIN users u ON s.student_id = u.id
    WHERE s.assignment_id = ? AND s.score IS NOT NULL
    ORDER BY s.score ASC
    LIMIT 3
  `;

  db.query(statsSql, [assignmentId], (err, statsResult) => {
    if (err) return res.status(500).json({ error: err.message });
    db.query(topSql, [assignmentId], (err, topResult) => {
      if (err) return res.status(500).json({ error: err.message });
      db.query(bottomSql, [assignmentId], (err, bottomResult) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({
          stats:  statsResult[0],
          top:    topResult,
          bottom: bottomResult
        });
      });
    });
  });
});

// File upload & grading (unchanged)
app.post('/upload', upload.single('file'), (req, res) => {
  const { studentName, studentId, assignmentId } = req.body;
  const file = req.file;
  if (!file) {
    return res.status(400).json({ message: 'No file uploaded' });
  }
  const studentFile   = file.path;
  const referenceFile = 'uploads/reference-answer.pka';
  const py            = spawn('python', ['grade_packet_tracer.py', studentFile, referenceFile]);

  let output = '';
  py.stdout.on('data', data => output += data.toString());
  py.stderr.on('data', data => console.error(`Python error: ${data}`));

  py.on('close', () => {
    try {
      const { score, feedback } = JSON.parse(output);
      const sql = `
        INSERT INTO submissions 
          (student_id, assignment_id, score, feedback, submitted_at)
        VALUES (?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
          score = VALUES(score),
          feedback = VALUES(feedback),
          submitted_at = NOW()
      `;
      db.query(sql, [studentId, assignmentId, score, feedback], err => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Grading complete', score, feedback });
      });
    } catch (err) {
      res.status(500).json({ message: 'Grading failed', error: err.message });
    }
  });
});

// ─── START SERVER ──────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
